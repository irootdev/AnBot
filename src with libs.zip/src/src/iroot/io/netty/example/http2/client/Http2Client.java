/*
 * Copyright 2014 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License, version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */
package iroot.io.netty.example.http2.client;

import iroot.io.netty.bootstrap.Bootstrap;
import iroot.io.netty.buffer.Unpooled;
import iroot.io.netty.channel.Channel;
import iroot.io.netty.channel.ChannelOption;
import iroot.io.netty.channel.EventLoopGroup;
import iroot.io.netty.channel.nio.NioEventLoopGroup;
import iroot.io.netty.channel.socket.nio.NioSocketChannel;
import iroot.io.netty.handler.codec.http.DefaultFullHttpRequest;
import iroot.io.netty.handler.codec.http.FullHttpRequest;
import iroot.io.netty.handler.codec.http.HttpHeaderNames;
import iroot.io.netty.handler.codec.http.HttpHeaderValues;
import iroot.io.netty.handler.codec.http2.Http2OrHttpChooser.SelectedProtocol;
import iroot.io.netty.handler.codec.http2.Http2SecurityUtil;
import iroot.io.netty.handler.ssl.ApplicationProtocolConfig;
import iroot.io.netty.handler.ssl.ApplicationProtocolConfig.Protocol;
import iroot.io.netty.handler.ssl.ApplicationProtocolConfig.SelectedListenerFailureBehavior;
import iroot.io.netty.handler.ssl.ApplicationProtocolConfig.SelectorFailureBehavior;
import iroot.io.netty.handler.ssl.SslContext;
import iroot.io.netty.handler.ssl.SslProvider;
import iroot.io.netty.handler.ssl.SupportedCipherSuiteFilter;
import iroot.io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import iroot.io.netty.util.CharsetUtil;

import java.net.URI;
import java.util.concurrent.TimeUnit;

import static iroot.io.netty.handler.codec.http.HttpMethod.GET;
import static iroot.io.netty.handler.codec.http.HttpMethod.POST;
import static iroot.io.netty.handler.codec.http.HttpVersion.HTTP_1_1;

/**
 * An HTTP2 client that allows you to send HTTP2 frames to a server. Inbound and outbound frames are
 * logged. When run from the command-line, sends a single HEADERS frame to the server and gets back
 * a "Hello World" response.
 */
public final class Http2Client {

    static final boolean SSL = System.getProperty("ssl") != null;
    static final String HOST = System.getProperty("host", "127.0.0.1");
    static final int PORT = Integer.parseInt(System.getProperty("port", SSL? "8443" : "8080"));
    static final String URL = System.getProperty("url", "/whatever");
    static final String URL2 = System.getProperty("url2");
    static final String URL2DATA = System.getProperty("url2data", "test data!");

    public static void main(String[] args) throws Exception {
        // Configure SSL.
        final SslContext sslCtx;
        if (SSL) {
            sslCtx = SslContext.newClientContext(SslProvider.JDK,
                                                 null, InsecureTrustManagerFactory.INSTANCE,
                                                 Http2SecurityUtil.CIPHERS,
                    /* NOTE: the following filter may not include all ciphers required by the HTTP/2 specification
                     * Please refer to the HTTP/2 specification for cipher requirements. */
                    SupportedCipherSuiteFilter.INSTANCE,
                    new ApplicationProtocolConfig(
                            Protocol.ALPN,
                            SelectorFailureBehavior.FATAL_ALERT,
                            SelectedListenerFailureBehavior.FATAL_ALERT,
                            SelectedProtocol.HTTP_2.protocolName(),
                            SelectedProtocol.HTTP_1_1.protocolName()),
                    0, 0);
        } else {
            sslCtx = null;
        }

        EventLoopGroup workerGroup = new NioEventLoopGroup();
        Http2ClientInitializer initializer = new Http2ClientInitializer(sslCtx, Integer.MAX_VALUE);

        try {
            // Configure the client.
            Bootstrap b = new Bootstrap();
            b.group(workerGroup);
            b.channel(NioSocketChannel.class);
            b.option(ChannelOption.SO_KEEPALIVE, true);
            b.remoteAddress(HOST, PORT);
            b.handler(initializer);

            // Start the client.
            Channel channel = b.connect().syncUninterruptibly().channel();
            System.out.println("Connected to [" + HOST + ':' + PORT + ']');

            // Wait for the HTTP/2 upgrade to occur.
            Http2SettingsHandler http2SettingsHandler = initializer.settingsHandler();
            http2SettingsHandler.awaitSettings(5, TimeUnit.SECONDS);

            HttpResponseHandler responseHandler = initializer.responseHandler();
            int streamId = 3;
            URI hostName = URI.create((SSL ? "https" : "http") + "://" + HOST + ':' + PORT);
            System.err.println("Sending request(s)...");
            if (URL != null) {
                // Create a simple GET request.
                FullHttpRequest request = new DefaultFullHttpRequest(HTTP_1_1, GET, URL);
                request.headers().add(HttpHeaderNames.HOST, hostName);
                request.headers().add(HttpHeaderNames.ACCEPT_ENCODING, HttpHeaderValues.GZIP);
                request.headers().add(HttpHeaderNames.ACCEPT_ENCODING, HttpHeaderValues.DEFLATE);
                channel.writeAndFlush(request);
                responseHandler.put(streamId, channel.newPromise());
                streamId += 2;
            }
            if (URL2 != null) {
                // Create a simple POST request with a body.
                FullHttpRequest request = new DefaultFullHttpRequest(HTTP_1_1, POST, URL2,
                                Unpooled.copiedBuffer(URL2DATA.getBytes(CharsetUtil.UTF_8)));
                request.headers().add(HttpHeaderNames.HOST, hostName);
                request.headers().add(HttpHeaderNames.ACCEPT_ENCODING, HttpHeaderValues.GZIP);
                request.headers().add(HttpHeaderNames.ACCEPT_ENCODING, HttpHeaderValues.DEFLATE);
                channel.writeAndFlush(request);
                responseHandler.put(streamId, channel.newPromise());
                streamId += 2;
            }
            responseHandler.awaitResponses(5, TimeUnit.SECONDS);
            System.out.println("Finished HTTP/2 request(s)");

            // Wait until the connection is closed.
            channel.close().syncUninterruptibly();
        } finally {
            workerGroup.shutdownGracefully();
        }
    }
}
